Mulambos do Asfalto

Este é um projeto simples que exibe vídeos relacionados a um acidente de trânsito e algumas atividades de um grupo chamado "Mulambos do Asfalto". Abaixo, você encontrará instruções sobre como visualizar o projeto e personalizar conforme necessário.

Estrutura do Projeto
Acidente
A seção "Acidente" exibe informações sobre um acidente de trânsito, incluindo um vídeo e o local do incidente.

Vídeo do Acidente: Reproduz um vídeo relacionado ao acidente.
Local do Acidente: Exibe o local do acidente em um mapa do Google.
Vídeos dos Mulambos do Asfalto
Esta seção contém vídeos do grupo "Mulambos do Asfalto", incluindo passeios e visitas a cachoeiras.

Os Mulambos: Apresentação do grupo com um vídeo.
Cachoeira da Cabeça Quebrada: Vídeos de diferentes visitas a essa cachoeira em Guarapari, ES.
Cachoeira Águas de Pinon Matilde - ES: Vídeos relacionados a Matilde, ES.
Aniversário
Na seção "Aniversário", há um vídeo do aniversário de Quezia Dyna.

Personalização
Sinta-se à vontade para personalizar o projeto conforme necessário:

Conteúdo: Substitua os vídeos existentes pelos seus próprios vídeos.
Estilo CSS: Edite o arquivo styles.css para ajustar o estilo conforme suas preferências.
Divirta-se explorando o projeto "Mulambos do Asfalto"!